export class Errors {
  errors: {[key: string]: string} = {};
}
